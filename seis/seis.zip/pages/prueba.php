<?php



	print($_POST["id"][0]);



 ?>