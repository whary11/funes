<?php
	if (!isset($_SESSION["token"])) {
	    header("location: ../");
	}
 ?>
